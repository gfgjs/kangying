const recommendApis = {
    getRecommendsList: {
        url: '/forum/api/admin/article/recommends',
        method: 'get',
        showLoading: true
    }
}
export default recommendApis
