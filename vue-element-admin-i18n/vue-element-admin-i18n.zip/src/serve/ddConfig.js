export default {
    cropId: process.env.VUE_APP_CROP_ID,
    appId: process.env.VUE_APP_APP_ID,
    access_token: ''
}
