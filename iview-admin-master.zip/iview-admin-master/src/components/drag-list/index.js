import DragList from './drag-list.vue'
export default DragList
